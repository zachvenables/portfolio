import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Zachary Venables & Blake Perkins
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Sample test cases.
     */

    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        m.add("green");
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue");
        m.add("blue");
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddMulti() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue", "red", "orange");
        m.add("blue");
        m.add("red");
        m.add("orange");
        assertEquals(mExpected, m);

    }

    @Test
    public final void changeToExtractionZeroItem() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected, m);

    }

    @Test
    public final void changeToExtractionModeSingle() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected, m);

    }

    @Test
    public final void changeToExtractionModeMulti() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "green",
                "blue", "red");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue", "red");
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected, m);

    }

    @Test
    public final void changeToExtractionModeThirteen() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
                "13");

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(mExpected, m);
    }

    @Test
    public final void removeFirstOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1");

        m.changeToExtractionMode();
        String result = m.removeFirst();

        mExpected.changeToExtractionMode();
        String expectedResult = mExpected.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(expectedResult, result);
    }

    @Test
    public final void removeFirstMulti() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
                "13");

        m.changeToExtractionMode();
        String result = m.removeFirst();

        mExpected.changeToExtractionMode();
        String expectedResult = mExpected.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(expectedResult, result);
    }

    @Test
    public final void removeFirstUnOrderEntry() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "7348",
                "124", "17", "37", "419");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "7348", "124", "17", "37", "419");

        m.changeToExtractionMode();
        String result = m.removeFirst();

        mExpected.changeToExtractionMode();
        String expectedResult = mExpected.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(expectedResult, result);
    }

    @Test
    public final void removeFirstRemoveMany() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "7348",
                "124", "17", "37", "419");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "7348", "124", "17", "37", "419");

        m.changeToExtractionMode();
        String resultA = m.removeFirst();
        String resultB = m.removeFirst();
        String resultC = m.removeFirst();

        mExpected.changeToExtractionMode();
        String expectedResultA = mExpected.removeFirst();
        String expectedResultB = mExpected.removeFirst();
        String expectedResultC = mExpected.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(expectedResultA, resultA);
        assertEquals(expectedResultB, resultB);
        assertEquals(expectedResultC, resultC);
    }

    @Test
    public final void removeFirstRemoveUntilEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "7348",
                "124", "17", "37", "419");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "7348", "124", "17", "37", "419");

        m.changeToExtractionMode();
        String resultA = m.removeFirst();
        String resultB = m.removeFirst();
        String resultC = m.removeFirst();
        String resultD = m.removeFirst();

        mExpected.changeToExtractionMode();
        String expectedResultA = mExpected.removeFirst();
        String expectedResultB = mExpected.removeFirst();
        String expectedResultC = mExpected.removeFirst();
        String expectedResultD = mExpected.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(expectedResultA, resultA);
        assertEquals(expectedResultB, resultB);
        assertEquals(expectedResultC, resultC);
        assertEquals(expectedResultD, resultD);
    }

    @Test
    public final void isInInsertionModeBase() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "7348",
                "124", "17", "37", "419");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "7348", "124", "17", "37", "419");

        assertEquals(mExpected.isInInsertionMode(), m.isInInsertionMode());
    }

    @Test
    public final void isInInsertionModeFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "7348",
                "124", "17", "37", "419");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "7348", "124", "17", "37", "419");

        assertEquals(mExpected.isInInsertionMode(), m.isInInsertionMode());
    }

    @Test
    public final void sizeBaseInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void sizeOneInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1");

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void sizeMultiInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3");

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void sizeBaseExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void sizeOneExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1");

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void sizeMultiExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3", "4");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3", "4");

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(mExpected.size(), m.size());
    }

    @Test
    public final void orderTestEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        m.order();
        mExpected.order();

        assertEquals(mExpected.size(), m.size());
    }

    // TODO - add test cases for add, changeToExtractionMode, removeFirst,
    // isInInsertionMode, order, and size

}
