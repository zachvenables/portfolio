import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Zachary Venables && Blake Perkins
 *
 */
public abstract class NaturalNumberTest {

    private static final NaturalNumber NaturalNumber = null;

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /*
     * Test cases for constructors
     */
    @Test
    public final void testNoArgumentConstructor() {

        NaturalNumber natNum1 = this.constructorTest();
        NaturalNumber expectedNatNum1 = this.constructorRef();

        assertEquals(expectedNatNum1, natNum1);
    }

    /*
     * Test cases for int constructors
     */
    @Test
    public final void testIntConstructor() {

        NaturalNumber natNum1 = this.constructorTest(1);
        NaturalNumber expectedNatNum1 = this.constructorRef(1);

        assertEquals(expectedNatNum1, natNum1);
    }

    /*
     * Test cases for String constructors
     */
    @Test
    public final void testStringConstructor() {

        NaturalNumber natNum1 = this.constructorTest("1");
        NaturalNumber expectedNatNum1 = this.constructorRef("1");

        assertEquals(expectedNatNum1, natNum1);
    }

    /*
     * Test cases for NaturalNumber constructors
     */
    @Test
    public final void testNaturalNumberConstructor() {
        NaturalNumber test = new NaturalNumber1L(1);
        NaturalNumber natNum1 = this.constructorTest(test);
        NaturalNumber expectedNatNum1 = this.constructorRef(test);

        assertEquals(expectedNatNum1, natNum1);
    }

    /*
     * Test cases for kernel methods
     */
    @Test
    public final void testMutliply1() {

        NaturalNumber natNum1 = this.constructorTest();
        NaturalNumber expectedNatNum1 = this.constructorRef();

        natNum1.multiplyBy10(0);

        assertEquals(expectedNatNum1, natNum1);
    }

    @Test
    public final void testMutliply2() {

        NaturalNumber natNum1 = this.constructorTest();
        NaturalNumber expectedNatNum1 = this.constructorRef(1);

        natNum1.multiplyBy10(1);

        assertEquals(expectedNatNum1, natNum1);
    }

    @Test
    public final void testMutliply3() {

        NaturalNumber natNum1 = this.constructorTest(5);
        NaturalNumber expectedNatNum1 = this.constructorRef(50);

        natNum1.multiplyBy10(0);

        assertEquals(expectedNatNum1, natNum1);
    }

    @Test
    public final void testMutliply4() {

        NaturalNumber natNum1 = this.constructorTest(1);
        NaturalNumber expectedNatNum1 = this.constructorRef(15);

        natNum1.multiplyBy10(5);

        assertEquals(expectedNatNum1, natNum1);
    }

    @Test
    public final void testMutliply5() {

        NaturalNumber natNum1 = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber expectedNatNum1 = this.constructorRef(Integer.MAX_VALUE);

        expectedNatNum1.multiplyBy10(1);
        natNum1.multiplyBy10(1);

        assertEquals(expectedNatNum1, natNum1);
    }

    @Test
    public final void testDivide1() {
        NaturalNumber natNum1 = this.constructorTest("12345");
        NaturalNumber expectedNatNum1 = this.constructorRef("1234");
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 5);
    }

    @Test
    public final void testDivide2() {
        NaturalNumber natNum1 = this.constructorTest("0");
        NaturalNumber expectedNatNum1 = this.constructorRef("0");
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 0);
    }

    @Test
    public final void testDivide3() {
        NaturalNumber natNum1 = this.constructorTest("9");
        NaturalNumber expectedNatNum1 = this.constructorRef();
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 9);
    }

    @Test
    public final void testDivide4() {
        NaturalNumber natNum1 = this.constructorTest();
        NaturalNumber expectedNatNum1 = this.constructorRef("0");
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 0);
    }

    @Test
    public final void testDivide5() {
        NaturalNumber natNum1 = this.constructorTest();
        NaturalNumber expectedNatNum1 = this.constructorRef();
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 0);
    }

    @Test
    public final void testDivide6() {
        NaturalNumber natNum1 = this.constructorTest(10);
        NaturalNumber expectedNatNum1 = this.constructorRef(1);
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 0);
    }

    @Test
    public final void testDivide7() {
        NaturalNumber natNum1 = this.constructorTest(100);
        NaturalNumber expectedNatNum1 = this.constructorRef(10);
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 0);
    }

    @Test
    public final void testDivide8() {
        NaturalNumber natNum1 = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber expectedNatNum1 = this.constructorRef(214748364);
        int remainder = natNum1.divideBy10();

        assertEquals(natNum1, expectedNatNum1);
        assertEquals(remainder, 7);
    }

    @Test
    public final void testIsZero1() {
        NaturalNumber natNum1 = this.constructorTest();
        assertTrue(natNum1.isZero());
    }

    @Test
    public final void testIsZero2() {
        NaturalNumber natNum1 = this.constructorTest("1");
        assertTrue(!natNum1.isZero());
    }

}
