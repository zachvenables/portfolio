import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 * Simple HelloWorld program (clear of Checkstyle and FindBugs warnings).
 *
 * @author Zachary Venables and Blake Perkins
 *
 */

/**
 * Returns a -,+ integer, or zero as the first arg that is less than, greater,
 * or equal to than the second.
 *
 */

class mapValCompare implements Comparator<Map.Entry<String, Integer>> {

    @Override
    public int compare(Map.Entry<String, Integer> o1,
            Map.Entry<String, Integer> o2) {
        return o2.getValue().compareTo(o1.getValue());

    }

}

/**
 *
 * @author Zachary Venables and Blake Perkins
 *
 */
public final class TagCloudGeneratorWithJavaComponents {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private TagCloudGeneratorWithJavaComponents() {
        // no code needed here
    }

    /**
     *
     * @param inFile
     *            reads from input file
     * @param wordCount
     *            Map containing words and counts of occurrences
     * @returns counts of words in inFile
     */
    public static void getWords(Scanner inFile,
            Map<String, Integer> wordCount) {

        while (inFile.hasNext()) {
            String word = inFile.next().toLowerCase();
            if (wordCount.containsKey(word)) {
                int oldVal = wordCount.get(word);
                wordCount.replace(word, oldVal, oldVal + 1);
            } else {
                wordCount.put(word, 1);
            }
        }

    }

    /**
     *
     * @param wordCount
     *            Map containing words and counts of occurrences
     * @param wordFont
     *            Font of words associated words and word count
     * @param numberOfWords
     *            number total number of words
     * @returns font size for each word in file
     */
    public static void mapFont(Map<String, Integer> wordCount,
            Map<Map.Entry<String, Integer>, Integer> wordFont,
            int numberOfWords) {

        ArrayList<Entry<String, Integer>> listCount = new ArrayList<>();

        Iterator<Entry<String, Integer>> it = wordCount.entrySet().iterator();
        while (it.hasNext()) {
            listCount.add(it.next());
        }

        Comparator<Map.Entry<String, Integer>> sortVal = new mapValCompare();
        listCount.sort(sortVal);

        for (int i = 0; i < numberOfWords; i++) {
            wordFont.put(listCount.get(i), 0);
        }

        calculateFont(wordFont, listCount);

    }

    /**
     *
     * @param wordFont
     *            font of words associated with words and word count
     * @param listCount
     *            holds words and value of counts
     */
    public static void calculateFont(
            Map<Map.Entry<String, Integer>, Integer> wordFont,
            ArrayList<Map.Entry<String, Integer>> listCount) {

        int maxCount = 0;
        int minCount = Integer.MAX_VALUE;

        for (int i = 0; i < listCount.size(); i++) {
            int currentVal = listCount.get(i).getValue();
            if (currentVal > maxCount) {
                maxCount = currentVal;
            }
            if (currentVal < minCount) {
                minCount = currentVal;
            }
        }

        int fontSize = 0;
        int maxFont = 37;

        Map<Map.Entry<String, Integer>, Integer> temp = new HashMap<>();
        Iterator<Entry<Entry<String, Integer>, Integer>> it = wordFont
                .entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry<Map.Entry<String, Integer>, Integer> e = it.next();
            it.remove();
            double count = e.getKey().getValue();
            double font = Math.ceil(
                    (maxFont * (count - minCount) / (maxCount - minCount)));
            fontSize = (int) font;
            fontSize += 9;

            temp.put(e.getKey(), fontSize);
        }

        wordFont.clear();
        for (Entry<Entry<String, Integer>, Integer> e : temp.entrySet()) {
            wordFont.put(e.getKey(), e.getValue());
        }

    }

    /**
     *
     * @param outFile
     *            output file
     * @param inputFileName
     *            inputfile
     * @param numberOfWords
     *            total number of unique words in file
     */
    public static void printHeader(PrintWriter outFile, String inputFileName,
            int numberOfWords) {
        outFile.println("<html>");
        outFile.println("<head>");
        outFile.println("<title>Top " + numberOfWords + " words in "
                + inputFileName + "</title>");
        outFile.println(
                "<link href=\"http://cse.osu.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        outFile.println("</head>");
        outFile.println("<body>");
        outFile.println("<h2>Top " + numberOfWords + " words in "
                + inputFileName + "</h2>");
        outFile.println("<hr>");
        outFile.println("<div class=\"cdiv\">");
        outFile.println("<p class=\"cbox\">");
        //done
    }

    /**
     *
     * @param outFile
     *            output file
     * @param wordFont
     *            font of words
     */
    public static void printItems(PrintWriter outFile,
            Map<Map.Entry<String, Integer>, Integer> wordFont) {
        int size = wordFont.size();

        for (int i = 0; i < size; i++) {
            Map.Entry<Map.Entry<String, Integer>, Integer> maxEntry = null;

            for (Map.Entry<Map.Entry<String, Integer>, Integer> entry : wordFont
                    .entrySet()) {
                if (maxEntry == null || entry.getKey().getKey()
                        .compareTo(maxEntry.getKey().getKey()) < 0) {
                    maxEntry = entry;
                }
            }

            outFile.println("<span style=" + '"' + "cursor:default" + '"'
                    + " class=" + '"' + 'f' + maxEntry.getValue() + '"'
                    + " title=" + '"' + "count: " + maxEntry.getKey().getValue()
                    + '"' + ">" + maxEntry.getKey().getKey() + "</span>");

            wordFont.remove(maxEntry.getKey());
        }
    }

    /**
     *
     * @param outFile
     *            output file
     */
    public static void printFooter(PrintWriter outFile) {
        outFile.println("</p>");
        outFile.println("</div>");
        outFile.println("</body>");
        outFile.println("</html>");
        //done
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     * @throws IOException
     */
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String inputFileName = null;
        Scanner inFile = null;
        PrintWriter outFile = null;

        System.out.print("Enter input file name: ");
        try {
            inputFileName = in.nextLine();
            inFile = new Scanner(new File(inputFileName));
        } catch (IOException e) {
            System.out.println("Input file does not exist.");
            return;
        }

        try {
            System.out.print("Enter output file name: ");
            String outputFileName = in.nextLine();

            outFile = new PrintWriter(
                    new BufferedWriter(new FileWriter(outputFileName)));
        } catch (IOException e) {
            System.out.println("Issue creating output file.");
            return;
        }

        try {
            System.out.print("Enter a positive number of output words: ");
            int numberOfWords = Integer.parseInt(in.nextLine());

            //puts each word sep'd by space in arrList
            Map<String, Integer> wordCount = new HashMap<>();
            getWords(inFile, wordCount);

            //map the <words, counts> with a font of 0
            Map<Map.Entry<String, Integer>, Integer> wordFont = new HashMap<>();
            mapFont(wordCount, wordFont, numberOfWords);

            //prints page
            printHeader(outFile, inputFileName, numberOfWords);
            printItems(outFile, wordFont);
            printFooter(outFile);

            in.close();
            outFile.close();
        } catch (RuntimeException e) {
            System.out.println("Invalid number of words.");
            return;
        }

    }

}
