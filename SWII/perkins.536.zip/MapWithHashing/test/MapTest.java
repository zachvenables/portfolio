import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Zachary Venables Blake Perkins
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, value,
    // hasKey, and size

    /*
     * Test cases for constructors
     */
    @Test
    public final void testNoArgumentConstructor() {

        Map<String, String> map1 = this.createFromArgsTest();
        Map<String, String> expectedMap1 = this.createFromArgsRef();

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for constructors
     */
    @Test
    public final void testOneArgumentConstructor() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for add
     */
    @Test
    public final void testAddBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal");

        map1.add("twoKey", "twoVal");

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for add
     */
    @Test
    public final void testAddThirdToEnd() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        map1.add("threeKey", "threeVal");

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for add
     */
    @Test
    public final void testAddThirdToFront() {

        Map<String, String> map1 = this.createFromArgsTest("twoKey", "twoVal",
                "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        map1.add("oneKey", "oneVal");

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for add
     */
    @Test
    public final void testAddThirdToMiddle() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        map1.add("twoKey", "twoVal");

        assertEquals(expectedMap1, map1);
    }

    /*
     * Test cases for remove
     */
    @Test
    public final void testRemoveBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        Map.Pair<String, String> result = map1.remove("oneKey");
        Map.Pair<String, String> expectedResult = expectedMap1.remove("oneKey");

        assertEquals(expectedMap1, map1);
        assertEquals(expectedResult, result);
    }

    /*
     * Test cases for remove
     */
    @Test
    public final void testRemoveFromFront() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        Map.Pair<String, String> result = map1.remove("oneKey");
        Map.Pair<String, String> expectedResult = expectedMap1.remove("oneKey");

        assertEquals(expectedMap1, map1);
        assertEquals(expectedResult, result);
    }

    /*
     * Test cases for remove
     */
    @Test
    public final void testRemoveFromMid() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        Map.Pair<String, String> result = map1.remove("twoKey");
        Map.Pair<String, String> expectedResult = expectedMap1.remove("twoKey");

        assertEquals(expectedMap1, map1);
        assertEquals(expectedResult, result);
    }

    /*
     * Test cases for remove
     */
    @Test
    public final void testRemoveFromEnd() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        Map.Pair<String, String> result = map1.remove("threeKey");
        Map.Pair<String, String> expectedResult = expectedMap1
                .remove("threeKey");

        assertEquals(expectedMap1, map1);
        assertEquals(expectedResult, result);
    }

    /*
     * Test cases for removeAny
     */
    @Test
    public final void testRemoveAnyBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        Map.Pair<String, String> result = map1.removeAny();
        Map.Pair<String, String> expectedResult = expectedMap1.removeAny();

        assertEquals(expectedMap1, map1);
        assertEquals(expectedResult, result);
    }

    /*
     * Test cases for value
     */
    @Test
    public final void testValueBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        assertEquals(expectedMap1.value("oneKey"), map1.value("oneKey"));

    }

    /*
     * Test cases for haseKey
     */
    @Test
    public final void testHasKeyBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        assertEquals(expectedMap1.hasKey("oneKey"), map1.hasKey("oneKey"));

    }

    /*
     * Test cases for haseKey
     */
    @Test
    public final void testHasKeyFalseBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal");

        assertEquals(expectedMap1.hasKey("twoKey"), map1.hasKey("twoKey"));

    }

    /*
     * Test cases for size
     */
    @Test
    public final void testSizeBaseCase() {

        Map<String, String> map1 = this.createFromArgsTest();
        Map<String, String> expectedMap1 = this.createFromArgsRef();

        assertEquals(expectedMap1.size(), map1.size());

    }

    @Test
    public final void testSizeThreeCompare() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal");
        Map<String, String> expectedMap1 = this.createFromArgsRef("oneKey",
                "oneVal", "twoKey", "twoVal", "threeKey", "threeVal");

        assertEquals(expectedMap1.size(), map1.size());

    }

    @Test
    public final void testSizeFourTest() {

        Map<String, String> map1 = this.createFromArgsTest("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal", "fourKey",
                "fourVal");

        assertEquals(4, map1.size());

    }

    @Test
    public final void testSizeThreeRef() {

        Map<String, String> map1 = this.createFromArgsRef("oneKey", "oneVal",
                "twoKey", "twoVal", "threeKey", "threeVal", "fourKey",
                "fourVal");

        assertEquals(4, map1.size());

    }
}
