import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Zachary Venables & Blake Perkins
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size
    @Test
    public void testNoArgConstructor() {
        Set<String> set1 = this.createFromArgsTest();
        Set<String> expectedSet1 = this.createFromArgsRef();

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testSingleArgConstructor() {
        Set<String> set1 = this.createFromArgsTest("one");
        Set<String> expectedSet1 = this.createFromArgsRef("one");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testMultiArgConstructor() {
        Set<String> set1 = this.createFromArgsTest("one", "two", "three",
                "four");
        Set<String> expectedSet1 = this.createFromArgsRef("one", "two", "three",
                "four");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testAddNoVal() {
        Set<String> set1 = this.createFromArgsTest();
        Set<String> expectedSet1 = this.createFromArgsRef();

        set1.add("");
        expectedSet1.add("");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testAddSingleVal() {
        Set<String> set1 = this.createFromArgsTest();
        Set<String> expectedSet1 = this.createFromArgsRef();

        set1.add("one");
        expectedSet1.add("one");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testAddMultiVals() {
        Set<String> set1 = this.createFromArgsTest();
        Set<String> expectedSet1 = this.createFromArgsRef();

        set1.add("one");
        set1.add("two");
        set1.add("three");
        set1.add("four");

        expectedSet1.add("one");
        expectedSet1.add("two");
        expectedSet1.add("three");
        expectedSet1.add("four");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testRemoveMultiVal() {
        Set<String> set1 = this.createFromArgsTest("one", "two", "three");
        Set<String> expectedSet1 = this.createFromArgsRef("one", "two",
                "three");

        String result1 = set1.remove("one");
        String result2 = set1.remove("two");
        String expectedResult1 = expectedSet1.remove("one");
        String expectedResult2 = expectedSet1.remove("two");

        assertEquals(expectedSet1, set1);
        assertEquals(result1, expectedResult1);
        assertEquals(result2, expectedResult2);

    }

    @Test
    public void testRemoveFromRight() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c");

        String result = set1.remove("c");
        String expectedResult = expectedSet1.remove("c");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveFromLeft() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c");

        String result = set1.remove("a");
        String expectedResult = expectedSet1.remove("a");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveFromRightRight() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        String result = set1.remove("g");
        String expectedResult = expectedSet1.remove("g");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveFromRightLeft() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        String result = set1.remove("e");
        String expectedResult = expectedSet1.remove("e");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveFromLeftLeft() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        String result = set1.remove("a");
        String expectedResult = expectedSet1.remove("a");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveFromLeftRight() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        String result = set1.remove("c");
        String expectedResult = expectedSet1.remove("c");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveTopRoot() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        String result = set1.remove("d");
        String expectedResult = expectedSet1.remove("d");

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveAnySingleVal() {
        Set<String> set1 = this.createFromArgsTest("a");
        Set<String> expectedSet1 = this.createFromArgsRef("a");

        String result = set1.removeAny();
        String expectedResult = expectedSet1.removeAny();

        assertEquals(expectedSet1, set1);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testRemoveAnyHalfOfTheTree() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("d", "e", "f", "g");

        String resultA = set1.removeAny();
        String resultB = set1.removeAny();
        String resultC = set1.removeAny();

        assertEquals(expectedSet1, set1);
        assertEquals(resultA, "a");
        assertEquals(resultB, "b");
        assertEquals(resultC, "c");
    }

    @Test
    public void testRemoveAnyRemoveAll() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef();

        String resultA = set1.removeAny();
        String resultB = set1.removeAny();
        String resultC = set1.removeAny();
        String resultD = set1.removeAny();
        String resultE = set1.removeAny();
        String resultF = set1.removeAny();
        String resultG = set1.removeAny();

        assertEquals(expectedSet1, set1);
        assertEquals(resultA, "a");
        assertEquals(resultB, "b");
        assertEquals(resultC, "c");
        assertEquals(resultD, "d");
        assertEquals(resultE, "e");
        assertEquals(resultF, "f");
        assertEquals(resultG, "g");
    }

    @Test
    public void testContainsSingleVal() {
        Set<String> set1 = this.createFromArgsTest("a");
        Set<String> expectedSet1 = this.createFromArgsRef("a");

        assertEquals(expectedSet1.contains("a"), set1.contains("a"));
    }

    @Test
    public void testContainsSmallTree() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c");

        assertEquals(expectedSet1.contains("a"), set1.contains("a"));
        assertEquals(expectedSet1.contains("b"), set1.contains("b"));
        assertEquals(expectedSet1.contains("c"), set1.contains("c"));
    }

    @Test
    public void testContainsLargeTree() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        assertEquals(expectedSet1.contains("a"), set1.contains("a"));
        assertEquals(expectedSet1.contains("b"), set1.contains("b"));
        assertEquals(expectedSet1.contains("c"), set1.contains("c"));
        assertEquals(expectedSet1.contains("d"), set1.contains("d"));
        assertEquals(expectedSet1.contains("e"), set1.contains("e"));
        assertEquals(expectedSet1.contains("f"), set1.contains("f"));
        assertEquals(expectedSet1.contains("g"), set1.contains("g"));
    }

    @Test
    public void testContainsLargeTreeFalse() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        assertEquals(expectedSet1.contains("z"), set1.contains("z"));
    }

    @Test
    public void testSizeEmpty() {
        Set<String> set1 = this.createFromArgsTest();
        Set<String> expectedSet1 = this.createFromArgsRef();

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testSizeOne() {
        Set<String> set1 = this.createFromArgsTest("a");
        Set<String> expectedSet1 = this.createFromArgsRef("a");

        assertEquals(expectedSet1, set1);
    }

    @Test
    public void testSizeMulti() {
        Set<String> set1 = this.createFromArgsTest("a", "b", "c", "d", "e", "f",
                "g");
        Set<String> expectedSet1 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g");

        assertEquals(expectedSet1, set1);
    }

}
