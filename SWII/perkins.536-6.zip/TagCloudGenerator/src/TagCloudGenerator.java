import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;

/**
 * Wordcounting program that takes an input text file and prints and html file
 * consisting of each unique word and their count.
 *
 * @author Zachary Venables & Blake Perkins
 */

/**
 * Returns a negative integer,zero,or a positive integer as the first arguement
 * is less than,equal to, or greater than the second.
 *
 */
class StringComp implements Comparator<Pair<String, Integer>> {
    /**
     * @param o1
     *
     * @param o2
     *
     * @requires String to be a single world
     *
     * @ensures String with high beginning letter is first
     */
    @Override
    public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
        return o1.key().compareTo(o2.key());
    }
}

/**
 * Returns a -,+ integer, or zero as the first arg that is less than, greater,
 * or equal to than the second.
 *
 */
class IntComp implements Comparator<Pair<String, Integer>> {

    /**
     * @param o1
     *
     * @param o2
     *
     * @returns -,+, or zero based on the comparison
     * @ensures Integer with higher value is set first
     */
    @Override
    public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
        return o2.value().compareTo(o1.value());

    }

}

/**
 *
 * @author Zachary Venables & Blake Perkins
 *
 */
public final class TagCloudGenerator {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private TagCloudGenerator() {
        // no code needed here
    }

    /**
     * Prints the header of the .html file.
     *
     * @param inputFileName
     *            the name of the input file
     * @param outFile
     *            the name of the file that is being written
     * @param numberOfWords
     *            number of words in txt file
     */
    public static void printHeader(String inputFileName, SimpleWriter outFile,
            int numberOfWords) {
        outFile.println("<html>");
        outFile.println("<head>");
        outFile.println("<title>Top " + numberOfWords + " words in "
                + inputFileName + "</title>");
        outFile.println(
                "<link href=\"http://cse.osu.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        outFile.println("</head>");
        outFile.println("<body>");
        outFile.println("<h2>Top " + numberOfWords + " words in "
                + inputFileName + "</h2>");
        outFile.println("<hr>");
        outFile.println("<div class=\"cdiv\">");
        outFile.println("<p class=\"cbox\">");
    }

    /**
     * Prints the footer of the .html file.
     *
     * @param outFile
     *            the name of the file that is being written
     */
    public static void printFooter(SimpleWriter outFile) {
        outFile.println("</p>");
        outFile.println("</div>");
        outFile.println("</body>");
        outFile.println("</html>");

    }

    /**
     * Prints the body of the .html file.
     *
     * @param outFile
     *            the name of the output file
     * @param wordCount
     *            Map of key words mapped to the count of each word value
     * @param allWordArray
     *            an array of alphabetized words
     * @param numberOfWords
     *            number of words in txt file
     * @param wordFont
     *            map of key words mapped to font size
     */
    public static void printItems(SimpleWriter outFile,
            Map1L<String, Integer> wordFont, Map1L<String, Integer> wordCount,
            int numberOfWords) {

        Comparator<Map.Pair<String, Integer>> sortInt = new IntComp();
        SortingMachine<Map.Pair<String, Integer>> sortedWord = new SortingMachine1L<>(
                sortInt);
        int length = wordCount.size();
        for (int i = 0; i < length; i++) {
            Map.Pair<String, Integer> p = wordCount.removeAny();
            sortedWord.add(p);
        }

        sortedWord.changeToExtractionMode();

        Comparator<Map.Pair<String, Integer>> sortAlph = new StringComp();
        SortingMachine<Map.Pair<String, Integer>> sortedAlph = new SortingMachine1L<>(
                sortAlph);
        for (int i = 0; i < numberOfWords; i++) {
            sortedAlph.add(sortedWord.removeFirst());
        }
        sortedAlph.changeToExtractionMode();

        for (int i = 0; i < numberOfWords; i++) {
            Pair<String, Integer> pair = sortedAlph.removeFirst();

            outFile.println("<span style=" + '"' + "cursor:default" + '"'
                    + " class=" + '"' + 'f' + wordFont.value(pair.key()) + '"'
                    + " title=" + '"' + "count: " + pair.value() + '"' + ">"
                    + pair.key() + "</span>");

        }
    }

    /**
     * Builds an array of all the of the keys in wordCount.
     *
     * @param wordCount
     *            Map for storing the individual words as keys and their count
     *            as values
     * @param allWordArray
     *            Array of String that is of length wordCount.size()
     * @ensures All keys from wordCount are entered into allWordArray
     */
    public static void buildArray(Map1L<String, Integer> wordCount,
            String[] allWordArray) {
        int i = 0;
        for (Pair<String, Integer> total : wordCount) {
            allWordArray[i] = total.key();
            i++;
        }
    }

    /**
     * Maps the String word to wordCount or increases the corresponding map
     * value by 1.
     *
     * @param wordCount
     *            Map for storing the individual words as keys and their count
     *            as values
     * @param word
     *            String from input to be place in map or counted
     *
     * @ensures All String word are added to wordCount or are added to the value
     *          of wordCount
     */
    public static void mapWord(String word, Map1L<String, Integer> wordCount) {

        if (wordCount.hasKey(word)) {
            int current = wordCount.value(word);
            current++;
            wordCount.replaceValue(word, current);
        } else {
            wordCount.add(word, 1);
        }

    }

    /**
     * Adds each individual word from String line into the Sequence <String>
     * words.
     *
     * @param line
     *            Single line taken from the input file
     * @param words
     *            empty sequence used to hold each individual word from String
     *            line
     * @ensures Sequence<String> words contains all the the words from String
     *          line
     */
    public static void getWord(String line, Sequence<String> words) {
        StringBuilder word = new StringBuilder();

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (Character.isLetter(c)) {
                word.append(Character.toLowerCase(c));
            } else if (word.length() > 0) {
                words.add(0, word.toString());
                word.delete(0, word.length());
            }
        }

    }

    /**
     *
     * @param wordCount
     * @return count of word
     *
     *         finds the most occurring word in the input file
     */
    public static double findMaxCount(Map<String, Integer> wordCount) {
        double result = 0;

        for (Map.Pair<String, Integer> p : wordCount) {
            if (p.value() > result) {
                result = p.value();
            }
        }

        return result;
    }

    /**
     *
     * @param maxFont
     * @param minCount
     * @param maxCount
     * @param count
     * @return font size for a given word
     *
     *         calculates font for a given word
     */
    public static int calculateFont(double maxFont, double minCount,
            double maxCount, int count) {
        int fontSize = 0;
        if ((int) minCount < count) {
            double font = Math.ceil(
                    (maxFont * (count - minCount) / (maxCount - minCount)));
            fontSize = (int) font;
            fontSize += 11;
        } else {
            fontSize = 1;
        }

        return fontSize;
    }

    /**
     *
     * @param wordFont
     * @param wordCount
     * @param numberOfWords
     *
     *            assigns font size to word
     */
    public static void makeWordFont(Map<String, Integer> wordFont,
            Map<String, Integer> wordCount, int numberOfWords) {

        Map<String, Integer> temp = wordCount.newInstance();
        double maxFontSize = 37;
        double minCount = 1;
        double maxCount = findMaxCount(wordCount);

        int length = wordCount.size();

        for (int i = 0; i < length; i++) {
            Map.Pair<String, Integer> p = wordCount.removeAny();

            int count = p.value();
            int fontSize = calculateFont(maxFontSize, minCount, maxCount,
                    count);

            wordFont.add(p.key(), fontSize);

            temp.add(p.key(), p.value());
        }

        wordCount.transferFrom(temp);

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();

        out.print("Enter input file name: ");
        String inputFileName = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(inputFileName);

        out.print("Enter output file name: ");
        String outputFileName = in.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(outputFileName);

        out.print("Enter a positive number of output words: ");
        int numberOfWords = Integer.parseInt(in.nextLine());

        Map1L<String, Integer> wordCount = new Map1L<String, Integer>();
        Map1L<String, Integer> wordFont = new Map1L<String, Integer>();

        Sequence<String> words = new Sequence1L<>();
        String line;

        while (!inFile.atEOS()) {
            line = inFile.nextLine().toLowerCase();
            getWord(line, words);
            int time = words.length();
            for (int i = 0; i < time; i++) {
                mapWord(words.remove(0), wordCount);
            }
        }

        makeWordFont(wordFont, wordCount, numberOfWords);

        printHeader(inputFileName, outFile, numberOfWords);
        printItems(outFile, wordFont, wordCount, numberOfWords);
        printFooter(outFile);

        out.close();
        in.close();
        inFile.close();
        outFile.close();
    }

}
