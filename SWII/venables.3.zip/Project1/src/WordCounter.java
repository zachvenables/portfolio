import java.util.Arrays;

import components.map.Map.Pair;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Wordcounting program that takes an input text file and prints and html file
 * consisting of each unique word and their count.
 *
 * @author Zachary Venables
 */
public final class WordCounter {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * Prints the header of the .html file.
     *
     * @param inputFileName
     *            the name of the input file
     * @param outFile
     *            the name of the file that is being written
     */
    public static void printHeader(String inputFileName, SimpleWriter outFile) {
        outFile.println("<html>");
        outFile.println("<head>");
        outFile.println(
                "<title>Words Counted in " + inputFileName + "</title>");
        outFile.println("</head>");
        outFile.println("<body>");
        outFile.println("<h2>Words Counted in " + inputFileName + "</h2>");
        outFile.println("<hr />");
        outFile.println("<table border = \"1\">");
        outFile.println("<tr>");
        outFile.println("<th>Words</th>");
        outFile.println("<th>Counts</th>");
        outFile.println("</tr>");
    }

    /**
     * Prints the footer of the .html file.
     *
     * @param outFile
     *            the name of the file that is being written
     */
    public static void printFooter(SimpleWriter outFile) {
        outFile.println("</table>");
        outFile.println("</body>");
        outFile.println("</html>");

    }

    /**
     * Prints the body of the .html file.
     *
     * @param outFile
     *            the name of the output file
     * @param wordCount
     *            Map of key words mapped to the count of each word value
     * @param allWordArray
     *            an array of alphabetized words
     */
    public static void printItems(SimpleWriter outFile,
            Map1L<String, Integer> wordCount, String[] allWordArray) {
        for (int i = 0; i < allWordArray.length; i++) {
            outFile.println("<tr>");
            outFile.println("<td>" + allWordArray[i] + "</td>");
            outFile.println(
                    "<td>" + wordCount.value(allWordArray[i]) + "</td>");
            outFile.println("</tr>");
        }
    }

    /**
     * Builds an array of all the of the keys in wordCount.
     *
     * @param wordCount
     *            Map for storing the individual words as keys and their count
     *            as values
     * @param allWordArray
     *            Array of String that is of length wordCount.size()
     * @ensures All keys from wordCount are entered into allWordArray
     */
    public static void buildArray(Map1L<String, Integer> wordCount,
            String[] allWordArray) {
        int i = 0;
        for (Pair<String, Integer> total : wordCount) {
            allWordArray[i] = total.key();
            i++;
        }
    }

    /**
     * Maps the String word to wordCount or increases the corresponding map
     * value by 1.
     *
     * @param wordCount
     *            Map for storing the individual words as keys and their count
     *            as values
     * @param word
     *            String from input to be place in map or counted
     *
     * @ensures All String word are added to wordCount or are added to the value
     *          of wordCount
     */
    public static void mapWord(String word, Map1L<String, Integer> wordCount) {

        if (wordCount.hasKey(word)) {
            int current = wordCount.value(word);
            current++;
            wordCount.replaceValue(word, current);
        } else {
            wordCount.add(word, 1);
        }

    }

    /**
     * Adds each individual word from String line into the Sequence <String>
     * words.
     *
     * @param line
     *            Single line taken from the input file
     * @param words
     *            empty sequence used to hold each individual word from String
     *            line
     * @ensures Sequence<String> words contains all the the words from String
     *          line
     */
    public static void getWord(String line, Sequence<String> words) {
        StringBuilder word = new StringBuilder();

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (Character.isLetter(c)) {
                word.append(Character.toLowerCase(c));
            } else if (word.length() > 0) {
                words.add(0, word.toString());
                word.delete(0, word.length());
            }
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();

        out.print("Enter input file name: ");
        String inputFileName = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(inputFileName);

        out.print("Enter output file name: ");
        String outputFileName = in.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(outputFileName);

        Map1L<String, Integer> wordCount = new Map1L<String, Integer>();
        Sequence<String> words = new Sequence1L<>();
        String line;

        while (!inFile.atEOS()) {
            line = inFile.nextLine();
            getWord(line, words);
            for (int i = 0; i < words.length(); i++) {
                mapWord(words.remove(0), wordCount);
            }
        }

        String[] allWordArray = new String[wordCount.size()];
        buildArray(wordCount, allWordArray);

        Arrays.sort(allWordArray);

        printHeader(inputFileName, outFile);
        printItems(outFile, wordCount, allWordArray);
        printFooter(outFile);

        out.close();
        in.close();
        inFile.close();
        outFile.close();
    }

}
