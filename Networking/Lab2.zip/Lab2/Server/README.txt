#File Transfer Platform Lab2

This is a simple file transfer Server. Once it is running, it waits for clients to contact it, 
then sends contact information to clients so that they can transfer data packets.

##Installation

Included in this folder is a Server.java and Server.class file.  You can compile the Server.java file if you need to, or just issue the command
"java Server" to start

##Usage
Run the server BEFORE you try to run either client.

You do not need to enter and information for the server to run, but do note the IP address of the server, you will need this for the clients to send packets to the server.



