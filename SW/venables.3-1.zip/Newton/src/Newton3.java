import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Newton3 takes a user input positive number and calculates the square root. It
 * also allows the user to select the accuracy to which the square root is
 * calculated.
 *
 * @author Zachary Venables
 * @version 20180125
 *
 */
public final class Newton3 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton3() {
    }

    /**
     * Computes estimate of square root of x to within relative error e.
     *
     * @param x
     *            positive number to compute square root of
     * @param e
     *            used to calculate the accuracy of the square root
     * @return estimate of square root
     */
    private static double sqrt(double x, double e) {
        final double epsilon = e;
        final double exponent = 2.0;
        final double divisor = 2.0;
        double r = x;
        double root = x / divisor;

        while (Math.abs(Math.pow(root, exponent) - x) / x >= Math.pow(epsilon,
                exponent) && r != 0) {
            r = root;
            root = (r + (x / r)) / divisor;
        }

        return root;
    }

    /**
     * Main method. Prompts the user for input,
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Prompts the user for input and assigns it to a variable
         */
        out.print("Enter a number for its square root: ");
        double num = in.nextDouble();

        out.print("Enter a value for accuracy: ");
        double accuracy = in.nextDouble();

        double root;
        boolean repeat = true;

        while (repeat) {
            root = sqrt(num, accuracy);

            out.println("The square root is approximately: " + root);

            out.print("Calculate another square root? (y/n): ");
            String yesNo = in.nextLine();

            /*
             * Evaluates if the user wants to continue calculating
             */
            if (!yesNo.equals("y")) {
                repeat = false;
            } else {
                out.print("Enter a number for its square root: ");
                num = in.nextDouble();

                out.print("Enter a value for accuracy: ");
                accuracy = in.nextDouble();
            }
        }

        out.print("Goodbye");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
