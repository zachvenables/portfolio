import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/*
 * Test cases for StringReassembly.java
 *
 *
 *  @author Zachary Venables
 */
public class StringReassemblyTest {

    @Test
    public void testCombination_unicorn_narwhal_1() {
        String str1 = "unicorn";
        String str2 = "narwhal";
        int overlap = 1;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("unicornarwhal", result);
    }

    @Test
    public void testCombination_narwhal_leglamp_1() {
        String str1 = "narwhal";
        String str2 = "leglamp";
        int overlap = 1;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("narwhaleglamp", result);
    }

    @Test
    public void testCombination_unicorn_corncob_4() {
        String str1 = "unicorn";
        String str2 = "corncob";
        int overlap = 4;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("unicorncob", result);
    }

    @Test
    public void testCombination_corncob_cobbler_3() {
        String str1 = "corncob";
        String str2 = "cobbler";
        int overlap = 3;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("corncobbler", result);
    }

    @Test
    public void testCombination_asymmetry_symmetry_8() {
        String str1 = "asymmetry";
        String str2 = "symmetry";
        int overlap = 8;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("asymmetry", result);
    }

    @Test
    public void testAddToSetAvoidingSubstrings_addStringOfOne() {
        Set<String> strSet = new Set1L<String>();
        strSet.add("b");
        strSet.add("c");
        strSet.add("d");
        strSet.add("e");
        strSet.add("f");
        strSet.add("g");

        String str = "a";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertTrue(strSet.contains(str));
    }

    @Test
    public void testAddToSetAvoidingSubstrings_addStringOfOneLast() {
        Set<String> strSet = new Set1L<String>();
        strSet.add("b");
        strSet.add("c");
        strSet.add("d");
        strSet.add("e");
        strSet.add("f");
        strSet.add("a");

        String str = "g";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertTrue(strSet.contains(str));
    }

    @Test
    public void testAddToSetAvoidingSubstrings_addStringOfFive() {
        Set<String> strSet = new Set1L<String>();
        strSet.add("Go");
        strSet.add("Beat Michigan");

        String str = "Bucks";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertTrue(strSet.contains(str));
    }

    @Test
    public void testAddToSetAvoidingSubstrings_redundantString() {
        Set<String> strSet = new Set1L<String>();
        strSet.add("Go Bucks");
        strSet.add("Beat Michigan");

        String str = "Bucks";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertTrue(!strSet.contains(str));
    }

    @Test
    public void testAddToSetAvoidingSubstrings_addHalfStringOverlap() {
        Set<String> strSet = new Set1L<String>();
        strSet.add("abracadabra");

        String str = "cadabramabra";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        assertTrue(strSet.contains(str));
    }

    @Test
    public void testLinesFromInput_noDuplicatesOrSubstrings() {
        SimpleReader input = new SimpleReader1L("data/test1.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);

        assertTrue(strSet.contains("cat"));
        assertTrue(strSet.contains("dog"));
        assertTrue(strSet.contains("pig"));
        assertTrue(strSet.contains("chicken"));
        assertTrue(strSet.contains("cow"));
    }

    @Test
    public void testLinesFromInput_oneStringManyTimes() {
        SimpleReader input = new SimpleReader1L("data/test2.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);

        assertTrue(strSet.contains("cat"));
        assertTrue(strSet.size() == 1);
    }

    @Test
    public void testLinesFromInput_oneDuplicate() {
        SimpleReader input = new SimpleReader1L("data/test3.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);

        assertTrue(strSet.contains("cat"));
        assertTrue(strSet.contains("dog"));
        assertTrue(strSet.contains("pig"));
        assertTrue(strSet.contains("chicken"));
        assertTrue(strSet.contains("cow"));
        assertTrue(strSet.size() == 5);
    }

    @Test
    public void testLinesFromInput_stringsWithSubstrings() {
        SimpleReader input = new SimpleReader1L("data/test4.txt");
        Set<String> strSet = StringReassembly.linesFromInput(input);

        assertTrue(strSet.contains("hamburger"));
        assertTrue(strSet.size() == 1);
    }

    @Test
    public void testPrintWithLineSeparators_stringsWithSubstrings() {
        SimpleWriter output = new SimpleWriter1L("data/printOut.txt");

        String str = "Hippopotamus~AntiDisestablishment~Hippopotamus";
        StringReassembly.printWithLineSeparators(str, output);

        SimpleReader input = new SimpleReader1L("data/printTest1.txt");
        SimpleReader inputCompare = new SimpleReader1L("data/printOut.txt");

        while (!input.atEOS()) {
            assertEquals(input.nextLine(), inputCompare.nextLine());
        }

        input.close();
        inputCompare.close();
        output.close();

    }

    @Test
    public void testPrintWithLineSeparators_justBreaks() {
        SimpleWriter output = new SimpleWriter1L("data/printOut.txt");

        String str = "~~~";
        StringReassembly.printWithLineSeparators(str, output);

        SimpleReader input = new SimpleReader1L("data/printTest2.txt");
        SimpleReader inputCompare = new SimpleReader1L("data/printOut.txt");

        while (!input.atEOS()) {
            assertEquals(input.nextLine(), inputCompare.nextLine());
        }

        input.close();
        inputCompare.close();
        output.close();
    }

    @Test
    public void testPrintWithLineSeparators_noBreaks() {
        SimpleWriter output = new SimpleWriter1L("data/printOut.txt");

        String str = "I only wear sunglasses at night.";
        StringReassembly.printWithLineSeparators(str, output);

        SimpleReader input = new SimpleReader1L("data/printTest3.txt");
        SimpleReader inputCompare = new SimpleReader1L("data/printOut.txt");

        while (!input.atEOS()) {
            assertEquals(input.nextLine(), inputCompare.nextLine());
        }

        input.close();
        inputCompare.close();
        output.close();
    }
}
