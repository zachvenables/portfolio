import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * This program takes a user input number (Mu), and then uses the de Jager
 * formula to calculate a value close to Mu.
 *
 * @author Zachary Venables
 *
 */
public final class ABCDGuesser1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser1() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        out.print("Enter a value for Mu (Positive value): ");
        String mu = in.nextLine();
        double doubleMu = 0.0;

        boolean check = true;
        while (check) {

            if (!FormatChecker.canParseDouble(mu)) {
                out.print("Invalid.  Please enter a positive number: ");
                mu = in.nextLine();
            } else {
                doubleMu = Double.parseDouble(mu);
                if (doubleMu >= 0.0) {
                    check = false;
                } else {
                    out.print("Invalid. Enter a positive number: ");
                    mu = in.nextLine();
                }
            }
        }

        return doubleMu;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        out.print("Enter a positive number not equal to one: ");
        String value = in.nextLine();

        double doubleVal = 0.0;
        boolean check = true;

        while (check) {
            if (!FormatChecker.canParseDouble(value)) {
                out.print(
                        "Invalid. Enter a positive number not equal to one: ");
                value = in.nextLine();
            } else {
                doubleVal = Double.parseDouble(value);
                if (doubleVal != 1.0 && doubleVal >= 0.0) {
                    check = false;
                } else {
                    out.print(
                            "Invalid. Enter a positive number not equal to one: ");
                    value = in.nextLine();
                }
            }
        }

        return doubleVal;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        double mu = getPositiveDouble(in, out);

        double valW = getPositiveDoubleNotOne(in, out);
        double valX = getPositiveDoubleNotOne(in, out);
        double valY = getPositiveDoubleNotOne(in, out);
        double valZ = getPositiveDoubleNotOne(in, out);

        double valA, valB, valC, valD;
        double estimate, bestEstimate = 0.0;
        double bestExpA = 0.0, bestExpB = 0.0, bestExpC = 0.0, bestExpD = 0.0;

        final double[] exponents = { -5.0, -4.0, -3.0, -2.0, -1.0, -1.0 / 2.0,
                -1.0 / 3.0, -1.0 / 4.0, 0.0, 1.0 / 4.0, 1.0 / 3.0, 1.0 / 2.0,
                1.0, 2.0, 3.0, 4.0, 5.0 };

        int i = 0;
        while (i < exponents.length) {
            valA = (Math.pow(valW, exponents[i]));

            int j = 0;
            while (j < exponents.length) {
                valB = (Math.pow(valX, exponents[j]));

                int k = 0;
                while (k < exponents.length) {
                    valC = (Math.pow(valY, exponents[k]));

                    int l = 0;
                    while (l < exponents.length) {
                        valD = (Math.pow(valZ, exponents[l]));

                        estimate = valA * valB * valC * valD;

                        if (Math.abs(mu - estimate) < Math
                                .abs(mu - bestEstimate)) {
                            bestEstimate = estimate;
                            bestExpA = exponents[i];
                            bestExpB = exponents[j];
                            bestExpC = exponents[k];
                            bestExpD = exponents[l];
                        }
                        l++;
                    }
                    k++;
                }
                j++;
            }
            i++;
        }
        double relativeError = 0.0;
        final int percent = 100;
        if (mu != 0.0) {
            relativeError = (Math.abs(mu - bestEstimate) / mu) * percent;
        }

        final int accuracy = 2;
        out.println("Exponent values: " + bestExpA + ", " + bestExpB + ", "
                + bestExpC + ", " + bestExpD);
        out.println("The best approximation is: " + bestEstimate);
        out.print("The relative error is: ");
        out.print(relativeError, accuracy, false);
        out.print("%");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();

    }

}
