import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * This program takes a user input number (Mu), and then uses the de Jager
 * formula to calculate a value close to Mu.
 *
 * @author Zachary Venables
 * @version 20180202
 *
 */
public final class ABCDGuesser2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser2() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        out.print("Enter a value for Mu (Positive value): ");
        String mu = in.nextLine();
        double doubleMu = 0.0;

        boolean check = true;
        while (check) {

            if (!FormatChecker.canParseDouble(mu)) {
                out.print("Invalid.  Please enter a positive number: ");
                mu = in.nextLine();
            } else {
                doubleMu = Double.parseDouble(mu);
                if (doubleMu >= 0.0) {
                    check = false;
                } else {
                    out.print("Invalid. Enter a positive number: ");
                    mu = in.nextLine();
                }
            }
        }

        return doubleMu;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        out.print("Enter a positive number not equal to one: ");
        String value = in.nextLine();

        double doubleVal = 0.0;
        boolean check = true;

        while (check) {
            if (!FormatChecker.canParseDouble(value)) {
                out.print(
                        "Invalid. Enter a positive number not equal to one: ");
                value = in.nextLine();
            } else {
                doubleVal = Double.parseDouble(value);
                if (doubleVal != 1.0 && doubleVal >= 0.0) {
                    check = false;
                } else {
                    out.print(
                            "Invalid. Enter a positive number not equal to one: ");
                    value = in.nextLine();
                }
            }
        }

        return doubleVal;
    }

    /**
     * Calculates relative error of user selected value and calculation of De
     * Jager Formula.
     *
     * @param mu
     *            the input double for user selected value
     * @param bestEstimate
     *            closest guess using De Jager formula
     * @return double value of relative error of calculation
     */
    private static double getRelativeError(double mu, double bestEstimate) {
        final int percent = 100;
        double value = 0.0;
        if (mu != 0.0) {
            value = (Math.abs(mu - bestEstimate) / mu) * percent;
        }
        return value;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        double mu = getPositiveDouble(in, out);

        double valW = getPositiveDoubleNotOne(in, out);
        double valX = getPositiveDoubleNotOne(in, out);
        double valY = getPositiveDoubleNotOne(in, out);
        double valZ = getPositiveDoubleNotOne(in, out);

        double valA, valB, valC, valD;
        double estimate, bestEstimate = 0.0;
        double bestExpA = 0.0, bestExpB = 0.0, bestExpC = 0.0, bestExpD = 0.0;

        final double[] exponents = { -5.0, -4.0, -3.0, -2.0, -1.0, -1.0 / 2.0,
                -1.0 / 3.0, -1.0 / 4.0, 0.0, 1.0 / 4.0, 1.0 / 3.0, 1.0 / 2.0,
                1.0, 2.0, 3.0, 4.0, 5.0 };

        for (int i = 0; i < exponents.length; i++) {
            valA = (Math.pow(valW, exponents[i]));

            for (int j = 0; j < exponents.length; j++) {
                valB = (Math.pow(valX, exponents[j]));

                for (int k = 0; k < exponents.length; k++) {
                    valC = (Math.pow(valY, exponents[k]));

                    for (int l = 0; l < exponents.length; l++) {
                        valD = (Math.pow(valZ, exponents[l]));

                        estimate = valA * valB * valC * valD;

                        if (Math.abs(mu - estimate) < Math
                                .abs(mu - bestEstimate)) {
                            bestEstimate = estimate;
                            bestExpA = exponents[i];
                            bestExpB = exponents[j];
                            bestExpC = exponents[k];
                            bestExpD = exponents[l];
                        }
                    }
                }
            }
        }

        double relativeError = getRelativeError(mu, bestEstimate);

        final int accuracy = 2;
        out.println("Exponent values: " + bestExpA + ", " + bestExpB + ", "
                + bestExpC + ", " + bestExpD);
        out.println("The best approximation is: " + bestEstimate);
        out.print("The relative error is: ");
        out.print(relativeError, accuracy, false);
        out.print("%");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();

    }

}
