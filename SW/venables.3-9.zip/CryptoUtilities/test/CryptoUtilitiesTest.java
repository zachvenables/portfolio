import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Zachary Venables
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    @Test
    public void testReduceToGCD_0_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("0", n.toString());
        assertEquals("0", m.toString());
    }

    @Test
    public void testReduceToGCD_30_21() {
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber m = new NaturalNumber2(21);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("3", n.toString());
        assertEquals("0", m.toString());
    }

    @Test
    public void testReduceToGCD_26_13() {
        NaturalNumber n = new NaturalNumber2(26);
        NaturalNumber m = new NaturalNumber2(13);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("13", n.toString());
        assertEquals("0", m.toString());
    }

    @Test
    public void testReduceToGCD_121_44() {
        NaturalNumber n = new NaturalNumber2(121);
        NaturalNumber m = new NaturalNumber2(44);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("11", n.toString());
        assertEquals("0", m.toString());
    }

    @Test
    public void testReduceToGCD_49_21() {
        NaturalNumber n = new NaturalNumber2(49);
        NaturalNumber m = new NaturalNumber2(21);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals("7", n.toString());
        assertEquals("0", m.toString());
    }

    /*
     * Tests of isEven
     */

    @Test
    public void testIsEven_0() {
        NaturalNumber n = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("0", n.toString());
        assertTrue(result);
    }

    @Test
    public void testIsEven_1() {
        NaturalNumber n = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("1", n.toString());
        assertTrue(!result);
    }

    @Test
    public void testIsEven_2() {
        NaturalNumber n = new NaturalNumber2(2);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("2", n.toString());
        assertTrue(result);
    }

    @Test
    public void testIsEven_11() {
        NaturalNumber n = new NaturalNumber2(11);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("11", n.toString());
        assertTrue(!result);
    }

    @Test
    public void testIsEven_146() {
        NaturalNumber n = new NaturalNumber2(146);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals("146", n.toString());
        assertTrue(result);
    }

    /*
     * Tests of powerMod
     */

    @Test
    public void testPowerMod_0_0_2() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("0", p.toString());
        assertEquals("2", m.toString());
    }

    @Test
    public void testPowerMod_17_18_19() {
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("18", p.toString());
        assertEquals("19", m.toString());
    }

    @Test
    public void testPowerMod_1_13_14() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(13);
        NaturalNumber m = new NaturalNumber2(14);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("13", p.toString());
        assertEquals("14", m.toString());
    }

    @Test
    public void testPowerMod_1_37_38() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(37);
        NaturalNumber m = new NaturalNumber2(38);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals("1", n.toString());
        assertEquals("37", p.toString());
        assertEquals("38", m.toString());
    }

    /*
     * Tests of isWitnessToCompositeness
     */

    @Test
    public void isWitnessToCompositeness_4_2() {
        NaturalNumber w = new NaturalNumber2(2);
        NaturalNumber n = new NaturalNumber2(4);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(result);
    }

    @Test
    public void isWitnessToCompositeness_6_3() {
        NaturalNumber w = new NaturalNumber2(3);
        NaturalNumber n = new NaturalNumber2(6);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(result);
    }

    @Test
    public void isWitnessToCompositeness_13_3() {
        NaturalNumber w = new NaturalNumber2(3);
        NaturalNumber n = new NaturalNumber2(13);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(!result);
    }

    @Test
    public void isWitnessToCompositeness_27_3() {
        NaturalNumber w = new NaturalNumber2(3);
        NaturalNumber n = new NaturalNumber2(27);
        boolean result = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertTrue(result);
    }

    @Test
    public void isPrime2_3() {
        NaturalNumber n = new NaturalNumber2(3);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }

    @Test
    public void isPrime2_5() {
        NaturalNumber n = new NaturalNumber2(5);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }

    @Test
    public void isPrime2_7() {
        NaturalNumber n = new NaturalNumber2(7);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }

    @Test
    public void isPrime2_11() {
        NaturalNumber n = new NaturalNumber2(11);
        boolean result = CryptoUtilities.isPrime2(n);
        assertTrue(result);
    }

    @Test
    public void generateNextLikelyPrime_57() {
        NaturalNumber n = new NaturalNumber2(57);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("59", n.toString());
        boolean prime = CryptoUtilities.isPrime1(n);
        assertTrue(prime);

    }

    @Test
    public void generateNextLikelyPrime_44() {
        NaturalNumber n = new NaturalNumber2(44);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("47", n.toString());
        boolean prime = CryptoUtilities.isPrime1(n);
        assertTrue(prime);

    }

    @Test
    public void generateNextLikelyPrime_8() {
        NaturalNumber n = new NaturalNumber2(8);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("11", n.toString());
        boolean prime = CryptoUtilities.isPrime1(n);
        assertTrue(prime);

    }

    @Test
    public void generateNextLikelyPrime_55() {
        NaturalNumber n = new NaturalNumber2(55);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("59", n.toString());
        boolean prime = CryptoUtilities.isPrime1(n);
        assertTrue(prime);

    }

    @Test
    public void generateNextLikelyPrime_64() {
        NaturalNumber n = new NaturalNumber2(64);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals("67", n.toString());
        boolean prime = CryptoUtilities.isPrime1(n);
        assertTrue(prime);

    }

}
