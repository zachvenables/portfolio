import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code NaturalNumber}.
 *
 * @author Zachary Venables
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     * Prints the given error message to the console and terminates the
     * application.
     *
     * @param msg
     *            the error message
     * @ensures [msg is printed to the console and the application terminates]
     */
    public static void fatalErrorToConsole(String msg) {
        assert msg != null : "Violation of: msg is not null";
        throw new RuntimeException(msg);
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"] and [no division by 0]
     *  and [Differences are not < zero]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        NaturalNumber result = new NaturalNumber2();
        NaturalNumber operandA = new NaturalNumber2();
        NaturalNumber operandB = new NaturalNumber2();

        if (exp.label().equals("number")) {
            result.setFromString(exp.attributeValue("value"));
        } else {
            if (exp.label().equals("plus")) {
                operandA.transferFrom(evaluate(exp.child(0)));
                operandB.transferFrom(evaluate(exp.child(1)));
                operandA.add(operandB);
                result.transferFrom(operandA);
            } else if (exp.label().equals("minus")) {
                operandA.transferFrom(evaluate(exp.child(0)));
                operandB.transferFrom(evaluate(exp.child(1)));

                if (operandA.compareTo(operandB) < 0) {
                    fatalErrorToConsole(
                            "Error. Difference cannot be less than zero.");
                }

                operandA.subtract(operandB);
                result.transferFrom(operandA);
            } else if (exp.label().equals("times")) {
                operandA.transferFrom(evaluate(exp.child(0)));
                operandB.transferFrom(evaluate(exp.child(1)));
                operandA.multiply(operandB);
                result.transferFrom(operandA);
            } else if (exp.label().equals("divide")) {
                operandA.transferFrom(evaluate(exp.child(0)));
                operandB.transferFrom(evaluate(exp.child(1)));

                if (operandB.isZero()) {
                    fatalErrorToConsole("Error. Cannot divide by zero.");
                }
                operandA.divide(operandB);
                result.transferFrom(operandA);
            }
        }

        return result;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}
