import java.util.Arrays;

import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Takes a .txt file of words and definitions and creates an indexed glossary
 * page of all items.
 *
 * @author Zachary Venables
 *
 */
public final class GlossaryBuilder {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private GlossaryBuilder() {
    }

    /**
     * Prints a .html page for each item in strOne with the content from both
     * strOne and strTwo. The items from strOne should be printed in red.
     *
     * @param folder
     *            output for index.html
     * @param strOne
     *            Sequence of words from the input
     * @param strTwo
     *            Sequence of definitions from the input
     *
     * @requires String folder is a location that exists for storing the .html
     *           files
     *
     * @clears strOne, strTwo
     * @ensures <pre>
     * Each item from string one is printed as .html file into the String folder
     * location.  The page is formatted to have a bold lettered print of the item
     * from strOne
     * </pre>
     */
    public static void createDefinitionPages(String folder,
            Sequence<String> strOne, Sequence<String> strTwo) {

        while (strOne.length() > 0) {
            String nextWord = strOne.remove(0);
            String nextDef = strTwo.remove(0);
            SimpleWriter out = new SimpleWriter1L(
                    folder + "/" + nextWord + ".html");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>" + nextWord + "</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2><b><i><font color=\"red\">" + nextWord
                    + "</font></i></b></h2>");
            out.println("<blockquote>" + nextDef + "</blockquote>");
            out.println("<hr />");
            out.println("<p>Return to <a href=\"index.html\">Index</a>.</p>");
            out.println("</body>");
            out.println("</html>");

            out.close();

        }

    }

    /**
     * Prints the content for the index page, excluding the header and footer.
     * Prints each item from str in a column, each item being a link to its
     * corresponding definition .html page
     *
     * @param out
     *            output for index.html
     * @param str
     *            Sequence of words from the glossary
     *
     * @requires out.isOpen
     * @ensures <pre>
     * all items from str are printed with links the each item's definition page
     * </pre>
     */
    public static void indexPage(SimpleWriter out, Sequence<String> str) {

        int finish = str.length();
        for (int i = 0; i < finish; i++) {
            String word = str.entry(i);
            out.print("     <li> <a href=\"" + word + ".html\">");

            out.print(word);
            out.println("</a></li>");
        }

    }

    /**
     * Prints to out the header of the index page.
     *
     * @param out
     *            a string of the definition of a word
     *
     * @requires out.isOpen
     * @update out.content
     * @ensures <pre>
     * The header content is printed to the out file
     * </pre>
     */
    public static void printIndexHeader(SimpleWriter out) {

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Glossary</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Glossary</h2><ul>");
        out.println("   <h3>Index</h3>");

    }

    /**
     * Prints to out the footer of the index page.
     *
     * @param out
     *            a string of the definition of a word
     *
     * @requires out.isOpen
     * @update out.content
     * @ensures <pre>
     * The footer content is printed to the out file
     * </pre>
     */
    public static void printIndexFooter(SimpleWriter out) {
        out.print(" </ul>\r\n" + "  </body>\r\n" + "</html>");
    }

    /**
     * Alphabetizes Sequence <String> word and updates the Sequence <String> def
     * to correspond with the order of word.
     *
     * @param word
     *            a Sequence <String> words to be alphabetized
     * @param def
     *            corresponding definitions to terms
     *
     * @requires String definitions is not empty
     * @updates word , def
     * @ensures <pre>
     * word items are alphabetized and the defs are in corresponding order
     * </pre>
     */
    public static void alphabetizeSequence(Sequence<String> word,
            Sequence<String> def) {

        String[] wordArr = new String[word.length()];
        for (int i = 0; i < wordArr.length; i++) {
            wordArr[i] = word.remove(0);
        }

        Map<String, String> wordDef = new Map1L<>();
        for (int i = 0; i < wordArr.length; i++) {
            wordDef.add(wordArr[i], def.remove(0));
        }

        Arrays.sort(wordArr);

        for (int i = wordArr.length - 1; i >= 0; i--) {
            word.add(0, wordArr[i]);
        }
        for (int i = wordArr.length - 1; i >= 0; i--) {
            def.add(0, wordDef.value(wordArr[i]));
        }

    }

    /**
     * Checks the location before and after a string to verify that it is either
     * a ' ' or ','.
     *
     * @param word
     *            words from the glossary
     * @param definition
     *            definition of words
     *
     * @requires String word is in String definition
     * @return true if the chars before and after String word in definitions are
     *         ' ' or ',' or if it is the last string in the definition
     * @ensures <pre>
     * if the location before or after the String word is a ' ' , ',' or it is
     * the last char in the string definition
     *
     * </pre>
     *
     */
    public static boolean checkForNonLetters(String word, String definition) {
        boolean result = false;

        int firstLocation = definition.indexOf(word) - 1;
        int secondLocation = definition.indexOf(word) + word.length();

        char first = definition.charAt(firstLocation);
        char second = 'a';

        if (secondLocation != definition.length()) {
            second = definition.charAt(secondLocation);
        }

        if (secondLocation == definition.length()) {
            result = true;
        } else if ((first == ' ' || first == ',')
                && (second == ' ' || second == ',')) {
            result = true;
        }

        return result;
    }

    /**
     * Takes the definition of a word, and locates the presence of an item from
     * the Sequence <String> words. If that item is in the definition, it is
     * replaced by the corresponding link to the definition page of said word.
     *
     * @param words
     *            words from the glossary
     * @param definitions
     *            definition of words
     *
     * @requires String definitions is not empty
     *
     * @ensures <pre>
     * If any of the words are present in the definition they are replaced with
     * a link to the page for corresponding word
     * </pre>
     *
     */
    public static void linkRelevantTerms(Sequence<String> words,
            Sequence<String> definitions) {

        String definition = "";

        for (int j = 0; j < definitions.length(); j++) {
            definition = definitions.entry(j);
            for (int i = 0; i < words.length(); i++) {
                if (definition.contains(words.entry(i))
                        && checkForNonLetters(words.entry(i), definition)) {

                    definition = definition.substring(0,
                            definition.indexOf(words.entry(i))) + "<a href=\""
                            + words.entry(i) + ".html\">" + words.entry(i)
                            + "</a>"
                            + definition.substring(
                                    definition.indexOf(words.entry(i))
                                            + words.entry(i).length(),
                                    definition.length());
                    definitions.replaceEntry(j, definition);
                }
            }
        }
    }

    /**
     * Processes one text file feed and adds the first line to the Sequence
     * <String> words then adds all following lines before a blank line as an
     * item in the Sequence <String> definitions.
     *
     * @param input
     *            the text document with terms and definitions
     * @param words
     *            words from the glossary
     * @param defs
     *            creates the sequence of corresponding definitions
     * @updates words , defs
     * @requires input file is formatted to have a blank line between
     *           definitions and following terms
     * @ensures <pre>
     * The sequence of words is made up of terms from the input and that they
     * are in corresponding order with the sequence of definitions
     * </pre>
     */
    public static void sequenceInputValues(SimpleReader input,
            Sequence<String> words, Sequence<String> defs) {

        StringBuffer buf = new StringBuffer();
        while (!input.atEOS()) {
            words.add(0, input.nextLine());
            buf.append(input.nextLine());
            String nextAdd = input.nextLine();
            while (!nextAdd.isEmpty()) {
                buf.append(nextAdd);
                nextAdd = input.nextLine();
            }

            defs.add(0, buf.toString());
            buf.delete(0, buf.length());
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Please enter the name of an input file: ");
        String inputFile = in.nextLine();
        SimpleReader input = new SimpleReader1L(inputFile);

        Sequence<String> wordSeq = new Sequence1L<>();
        Sequence<String> defSeq = new Sequence1L<>();

        sequenceInputValues(input, wordSeq, defSeq);
        alphabetizeSequence(wordSeq, defSeq);
        linkRelevantTerms(wordSeq, defSeq);

        out.print("Please enter the name of an output folder: ");
        String outputFolder = in.nextLine();
        SimpleWriter output = new SimpleWriter1L(outputFolder + "/index.html");

        printIndexHeader(output);
        indexPage(output, wordSeq);
        printIndexFooter(output);

        createDefinitionPages(outputFolder, wordSeq, defSeq);

        in.close();
        out.close();
    }

}
