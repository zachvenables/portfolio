--------
Lab3
--------

This is a demonstration of kinematics.  The earth rotates around the sun and the moon rotates around the earth. They are all texturized and also
 rotate on their own central axis.