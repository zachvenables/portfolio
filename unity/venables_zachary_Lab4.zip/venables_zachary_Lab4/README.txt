AUTHOR: Zachary Venables
MoWeFri: 1:50 - 2:45


CONTENTS OF THIS FILE
-----------------------

*Lab4
*Lab4 Bonus Credit


INTRODUCTION
-----------------------

This is a unity package that will exhibit a mass-spring system on two objects. 
The Lab4 file is only on one moveable object.  Lab4 Bonus Credit is on two moveable objects.


OBJECT DETAILS
-----------------------

The objects are labeled obja and objb in the script titled massSpring.cs.  This is all of the 
calculations are done.  There are seperate calculations done for the forces of each object, and 
they are applied accordingly at the beginning of each new frame.  The calculations are identical
to the examples in the slides.